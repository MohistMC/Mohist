package cpw.mods.fml.common;

public interface FMLContainerHolder
{
    ModContainer getFMLContainer();
}
package cpw.mods.fml.relauncher;

import java.lang.reflect.Method;
import org.apache.logging.log4j.LogManager;
import red.mohist.Mohist;
import red.mohist.common.async.MohistThreadBox;
import red.mohist.down.DownloadLibraries;
import red.mohist.util.i18n.Message;

public class ServerLaunchWrapper {

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        new ServerLaunchWrapper().run(args);
    }

    private ServerLaunchWrapper()
    {

    }

    private void run(String[] args)
    {
        Class<?> launchwrapper = null;
        try
        {
            launchwrapper = Class.forName("net.minecraft.launchwrapper.Launch",true,getClass().getClassLoader());
            Class.forName("org.objectweb.asm.Type",true,getClass().getClassLoader());
            System.out.println("");
            System.out.println("");
            System.out.println(" /'\\_/`\\          /\\ \\       __          /\\ \\__   ");
            System.out.println("/\\      \\     ___ \\ \\ \\___  /\\_\\     ____\\ \\ ,_\\  ");
            System.out.println("\\ \\ \\__\\ \\   / __`\\\\ \\  _ `\\\\/\\ \\   /',__\\\\ \\ \\/  ");
            System.out.println(" \\ \\ \\_/\\ \\ /\\ \\L\\ \\\\ \\ \\ \\ \\\\ \\ \\ /\\__, `\\\\ \\ \\_ ");
            System.out.println("  \\ \\_\\\\ \\_\\\\ \\____/ \\ \\_\\ \\_\\\\ \\_\\\\/\\____/ \\ \\__\\");
            System.out.println("   \\/_/ \\/_/ \\/___/   \\/_/\\/_/ \\/_/ \\/___/   \\/__/");
            System.out.println("");
            System.out.println("");
            System.out.println("                        " + Message.getString("forge.serverlanunchwrapper.1"));
            System.out.println(Message.getString("mohist.start"));
            System.out.println(Message.getString("load.libraries"));
            Mohist.LOGGER = LogManager.getLogger("Mohist");
        }
        catch (Exception e)
        {
            System.out.println(Message.getString("mohist.start.error.nothavelibrary"));
            MohistThreadBox.DL.execute(new DownloadLibraries());
            System.out.println(Message.getString("file.ok"));
            MohistThreadBox.DL.shutdown();
        }

        try
        {
            Method main = launchwrapper != null ? launchwrapper.getMethod("main", String[].class) : null;
            String[] allArgs = new String[args.length + 2];
            allArgs[0] = "--tweakClass";
            allArgs[1] = "cpw.mods.fml.common.launcher.FMLServerTweaker";
            System.arraycopy(args, 0, allArgs, 2, args.length);
            main.invoke(null,(Object)allArgs);
        }
        catch (Exception e)
        {
            System.out.println(Message.getString("mohist.start.error"));
        }
    }

}